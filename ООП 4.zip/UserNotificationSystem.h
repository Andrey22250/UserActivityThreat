#pragma once
#include <string>
#include <iostream>

using namespace std;

class UserNotificationSystem
{
public:
	static string notifyUserAuto(const string& notify);
};

