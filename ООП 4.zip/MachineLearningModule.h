#pragma once
#include "IMachineLearning.h"

class MachineLearningModule : public IMachineLearning
{
private:
    string version;
public:
    void trainModel() override;
    void updateAlgorithm() override;
    void evaluatePerformance() override;
    void deployNewModel() override;
};

